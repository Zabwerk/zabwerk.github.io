#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""build_pdf.py — 编译译稿并做机器可查的版面/内容体检。

用法：
  python build_pdf.py path/to/main.tex --runs 2 --render-dir build/render --report build/report.json

检查：
  - xelatex 退出码、日志中的 "! " 错误、未定义引用/文献；
  - PDF 页数、空白页、"??" 未解析、禁用词（如下载来源标记）；
  - 字体是否嵌入、图片数量；
  - 逐页渲染 PNG，便于人工视觉核对。

退出码：0 = 通过；1 = 有需要处理的问题；2 = 输入/环境错误。
"""

from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys

try:
    import fitz
except ImportError:
    sys.stderr.write("需要 PyMuPDF：pip install pymupdf\n")
    raise SystemExit(2)


def run_xelatex(tex: str, runs: int):
    workdir = os.path.dirname(os.path.abspath(tex)) or "."
    logs = []
    for i in range(runs):
        cmd = ["xelatex", "-interaction=nonstopmode", os.path.basename(tex)]
        p = subprocess.run(cmd, cwd=workdir, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        out = p.stdout.decode("utf-8", errors="replace")
        logs.append(out)
        if p.returncode != 0 and i == 0:
            return p.returncode, out, workdir
    return 0, "\n".join(logs), workdir


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("tex")
    ap.add_argument("--runs", type=int, default=2)
    ap.add_argument("--render-dir", default="")
    ap.add_argument("--report", default="")
    ap.add_argument("--forbidden", action="append", default=["Downloaded from", "Authorized licensed use limited to"])
    ap.add_argument("--dpi", type=int, default=110)
    args = ap.parse_args()

    tex = os.path.abspath(args.tex)
    if not os.path.exists(tex):
        sys.stderr.write(f"找不到 {tex}\n")
        return 2

    code, log, workdir = run_xelatex(tex, args.runs)
    log_path = os.path.splitext(tex)[0] + ".log"
    if os.path.exists(log_path):
        log = open(log_path, encoding="utf-8", errors="replace").read()

    errors = re.findall(r"^! .*$", log, re.M)
    undefined_refs = re.findall(r"LaTeX Warning: Reference `([^']+)' on page", log)
    undefined_cites = re.findall(r"LaTeX Warning: Citation `([^']+)' on page", log)
    overfull = len(re.findall(r"Overfull \\hbox", log))

    m = re.search(r"Output written on .*?\((\d+) pages?", log)
    pages = int(m.group(1)) if m else 0

    pdf_path = os.path.splitext(tex)[0] + ".pdf"
    report = {
        "tex": tex,
        "xelatex_exit": code,
        "errors": errors[:20],
        "undefined_references": sorted(set(undefined_refs))[:30],
        "undefined_citations": sorted(set(undefined_cites))[:30],
        "overfull_hboxes": overfull,
        "pages": pages,
        "blank_pages": [],
        "unresolved_marks": 0,
        "forbidden_hits": [],
        "fonts": 0,
        "images": 0,
    }

    if code == 0 and os.path.exists(pdf_path):
        doc = fitz.open(pdf_path)
        report["pages"] = doc.page_count
        unresolved = 0
        text_all = []
        for i, pg in enumerate(doc):
            t = pg.get_text("text")
            text_all.append(t)
            if len(t.strip()) < 30:
                report["blank_pages"].append(i + 1)
            unresolved += t.count("??")
            report["images"] += len(pg.get_images(full=True))
        report["unresolved_marks"] = unresolved
        low = "\n".join(text_all).lower()
        report["forbidden_hits"] = [w for w in args.forbidden if w and w.lower() in low]
        fonts = set()
        for pg in doc:
            for f in pg.get_fonts(full=True):
                fonts.add(f[3])
        report["fonts"] = len(fonts)

        if args.render_dir:
            os.makedirs(args.render_dir, exist_ok=True)
            for i, pg in enumerate(doc):
                pg.get_pixmap(dpi=args.dpi).save(os.path.join(args.render_dir, f"page-{i+1:03d}.png"))

    problems = (code != 0 or errors or undefined_refs or undefined_cites or
                report["blank_pages"] or report["unresolved_marks"] or report["forbidden_hits"])
    report["ok"] = not problems

    if args.report:
        with open(args.report, "w", encoding="utf-8") as f:
            json.dump(report, f, ensure_ascii=False, indent=1)

    print(f"xelatex exit={code}  pages={report['pages']}  errors={len(errors)}  "
          f"undefined refs={len(set(undefined_refs))}  cites={len(set(undefined_cites))}  "
          f"overfull={overfull}")
    if report["blank_pages"]:
        print(f"空白页：{report['blank_pages']}")
    if report["forbidden_hits"]:
        print(f"禁用词命中：{report['forbidden_hits']}")
    if report["unresolved_marks"]:
        print(f"'??' 数量：{report['unresolved_marks']}")
    if errors:
        print("首个错误：" + errors[0][:200])
    print("PASS" if report["ok"] else "FAIL")
    return 0 if report["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
