#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""check_translation.py — 对照原文清单检查译稿的数值、引文与图表覆盖。

用法：
  python check_translation.py --source work/source.json --text src --report work/check.json

检查项：
  1. 原文数值（小数、百分比、千分位）是否能在译稿中找到；
  2. 原文文献编号 [n] / [n]–[m] 是否都在译稿 \cite 键中出现（键含数字时）；
  3. 图/表编号是否与原文一致（\label{fig...}/\label{tab...}）；
  4. 译稿引用的图片文件是否存在；
  5. 章节数量是否明显少于原文（漏译提示）。

退出码：0 = 通过；1 = 有缺项；2 = 输入错误。
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
from collections import Counter

FULLWIDTH = str.maketrans("０１２３４５６７８９．，％－", "0123456789.,%-")
NUM_RE = re.compile(r"\d+(?:[.,]\d+)?%?")
CITE_RE = re.compile(r"\[(\d+)(?:\s*[–\-—]\s*(\d+))?\]")
FIG_RE = re.compile(r"(?:Fig(?:ure)?\.?|图)\s*(\d+)", re.I)
TAB_RE = re.compile(r"(?:TABLE|Table|表)\s*([IVXLC]+|\d+)", re.I)
INCLUDE_RE = re.compile(r"\\includegraphics(?:\[[^\]]*\])?\{([^}]+)\}")
CITE_KEY_RE = re.compile(r"\\cite[a-zA-Z]*\*?(?:\[[^\]]*\])?\{([^}]*)\}")
LABEL_RE = re.compile(r"\\label\{([^}]*)\}")
ROMAN = {"I": 1, "V": 5, "X": 10, "L": 50, "C": 100}


def norm_number(tok: str) -> str:
    tok = tok.translate(FULLWIDTH).replace("%", "")
    if "," in tok:
        tok = tok.replace(",", "")
    if "." in tok:
        tok = tok.rstrip("0").rstrip(".")
    return tok


def roman_to_int(s: str) -> int:
    s = s.upper()
    if s.isdigit():
        return int(s)
    total, prev = 0, 0
    for ch in reversed(s):
        v = ROMAN.get(ch, 0)
        total += -v if v < prev else v
        prev = max(prev, v)
    return total


def int_to_roman(n: int) -> str:
    vals = [(100, "C"), (90, "XC"), (50, "L"), (40, "XL"), (10, "X"), (9, "IX"),
            (5, "V"), (4, "IV"), (1, "I")]
    out = ""
    for v, s in vals:
        while n >= v:
            out += s
            n -= v
    return out


def strip_tex(s: str) -> str:
    s = re.sub(r"(?<!\\)%.*", "", s)
    s = re.sub(r"\\(?:begin|end)\{[^}]*\}", " ", s)
    s = re.sub(r"\\(?:cite|ref|eqref|label)\{[^}]*\}", " ", s)
    s = re.sub(r"\\[a-zA-Z@]+\*?(?:\[[^\]]*\])?", " ", s)
    s = s.replace("{", " ").replace("}", " ").replace("\\", " ")
    return s


def strip_refs_for_numbers(s: str) -> str:
    """去掉文献编号与图表编号，避免把 [1]、Fig. 1 里的数字当成实验数值。"""
    s = CITE_RE.sub(" ", s)
    s = FIG_RE.sub(" ", s)
    s = TAB_RE.sub(" ", s)
    return s


def numbers_in(text: str):
    return Counter(norm_number(m.group(0)) for m in NUM_RE.finditer(text))


def expand_cites(text: str):
    out = set()
    for m in CITE_RE.finditer(text):
        a = int(m.group(1))
        b = int(m.group(2)) if m.group(2) else a
        if b < a:
            a, b = b, a
        out.update(range(a, b + 1))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--source", required=True, help="prepare_source.py 生成的 source.json")
    ap.add_argument("--text", required=True, help="译稿目录（.tex）或单个 .tex 文件")
    ap.add_argument("--report", default="", help="输出 JSON 报告路径")
    ap.add_argument("--max-list", type=int, default=40)
    args = ap.parse_args()

    if not os.path.exists(args.source):
        sys.stderr.write(f"找不到 {args.source}\n")
        return 2
    with open(args.source, encoding="utf-8") as f:
        src = json.load(f)

    src_lines = []
    for pg in src["pages_detail"]:
        for l in pg["lines"]:
            t = l["text"].strip()
            if re.match(r"^\[\d+\]", t):
                continue
            src_lines.append(t)
    src_text = "\n".join(src_lines)

    if not os.path.exists(args.text):
        sys.stderr.write(f"找不到 {args.text}\n")
        return 2
    if os.path.isdir(args.text):
        files = sorted(f for f in os.listdir(args.text) if f.endswith(".tex"))
        files = [os.path.join(args.text, f) for f in files]
    else:
        files = [args.text]
    tex_raw = "\n".join(open(f, encoding="utf-8", errors="replace").read() for f in files)
    tex_text = strip_tex(tex_raw)

    # 1) 数值（排除引文与图表编号）
    src_nums = numbers_in(strip_refs_for_numbers(src_text))
    tex_nums = numbers_in(strip_refs_for_numbers(tex_text))
    missing_nums = []
    for n, c in src_nums.most_common():
        if tex_nums.get(n, 0) < c:
            missing_nums.append({"number": n, "source_count": c, "translation_count": tex_nums.get(n, 0)})

    # 2) 引文
    src_cites = expand_cites(src_text)
    keys = []
    for grp in CITE_KEY_RE.findall(tex_raw):
        keys += [k.strip() for k in grp.split(",") if k.strip()]
    numeric_keys = set()
    for k in keys:
        for m in re.findall(r"\d+", k):
            numeric_keys.add(int(m))
    if numeric_keys:
        missing_cites = sorted(src_cites - numeric_keys)
        extra_cites = sorted(numeric_keys - src_cites)
        cite_mode = "numeric-keys"
    else:
        missing_cites, extra_cites = [], []
        cite_mode = "symbolic-keys（未按编号比对，仅记录键）"

    # 3) 图表
    src_figs = sorted({int(x) for x in FIG_RE.findall(src_text)})
    src_tabs = sorted({roman_to_int(x) for x in TAB_RE.findall(src_text)})
    labels = LABEL_RE.findall(tex_raw)
    tex_figs, tex_tabs = set(), set()
    for lb in labels:
        m = re.search(r"fig[:_-]?(\d+)", lb, re.I)
        if m:
            tex_figs.add(int(m.group(1)))
        m = re.search(r"tab[:_-]?(\d+)", lb, re.I)
        if m:
            tex_tabs.add(int(m.group(1)))
    tex_figs, tex_tabs = sorted(tex_figs), sorted(tex_tabs)

    # 4) 图片文件
    base = os.path.dirname(os.path.abspath(args.text)) if os.path.isfile(args.text) else os.path.abspath(args.text)
    missing_assets = []
    for inc in INCLUDE_RE.findall(tex_raw):
        p = inc if os.path.isabs(inc) else os.path.join(base, inc)
        if not os.path.exists(p):
            alt = [os.path.join(base, "figs", os.path.basename(inc)),
                   os.path.join(os.path.dirname(base), "figs", os.path.basename(inc))]
            if not any(os.path.exists(a) for a in alt):
                missing_assets.append(inc)

    src_head = len(src.get("headings", []))
    tex_sec = len(re.findall(r"\\section\*?\{", tex_raw))
    tex_sub = len(re.findall(r"\\subsection\*?\{", tex_raw))

    missing_figs = sorted(set(src_figs) - set(tex_figs))
    missing_tabs = sorted(set(src_tabs) - set(tex_tabs))
    ok = (not missing_nums and not missing_cites and not missing_assets
          and not missing_figs and not missing_tabs)

    report = {
        "ok": ok,
        "source": args.source,
        "text": args.text,
        "numbers": {
            "source_unique": len(src_nums),
            "missing": missing_nums[: args.max_list],
            "missing_total": len(missing_nums),
        },
        "citations": {
            "mode": cite_mode,
            "source_unique": len(src_cites),
            "cite_keys": len(keys),
            "missing": missing_cites,
            "extra": extra_cites,
        },
        "figures": {"source": src_figs, "translation": tex_figs, "missing": missing_figs},
        "tables": {"source": src_tabs, "translation": tex_tabs, "missing": missing_tabs},
        "missing_assets": missing_assets,
        "sections": {"source_headings": src_head, "tex_sections": tex_sec, "tex_subsections": tex_sub},
    }

    if args.report:
        with open(args.report, "w", encoding="utf-8") as f:
            json.dump(report, f, ensure_ascii=False, indent=1)

    print(f"数值：原文 {len(src_nums)} 种，缺 {len(missing_nums)} 种")
    for m in missing_nums[:15]:
        print(f"  - {m['number']}（原文 {m['source_count']} 次，译文 {m['translation_count']} 次）")
    print(f"引文：{cite_mode}；原文 {len(src_cites)} 个编号，缺 {len(missing_cites)} 个"
          + (f"：{missing_cites[:12]}" if missing_cites else ""))
    print(f"图：原文 {src_figs} / 译文 {tex_figs}" + (f"；缺 {missing_figs}" if missing_figs else ""))
    print(f"表：原文 {src_tabs} / 译文 {tex_tabs}" + (f"；缺 {missing_tabs}" if missing_tabs else ""))
    print(f"章节：原文候选 {src_head}，译文 section {tex_sec} + subsection {tex_sub}")
    if missing_assets:
        print(f"缺失图片：{missing_assets[:10]}")
    print("PASS" if ok else "FAIL")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
