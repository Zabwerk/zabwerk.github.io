#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""prepare_source.py — 把一篇论文 PDF 解析成可翻译、可核对的工程目录。

只读输入 PDF，不修改、不截取原文件。输出：
  <out>/source.json          结构化清单（页面、行、字体、图片 bbox、标题/章节候选）
  <out>/text/page-XXX.txt    按栏重排的阅读顺序文本
  <out>/pages/page-XXX.png   整页渲染（用于视觉核对）
  <out>/assets/img-*.png     从 PDF 提取的原始位图（用于图表复用）
  <out>/inventory.md         人读的内容清单
  <out>/coverage.csv         逐行覆盖表（翻译时填写状态）

用法：
  python prepare_source.py paper.pdf -o work --dpi 600
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import re
import sys
from collections import Counter

try:
    import fitz  # PyMuPDF
except ImportError:  # pragma: no cover
    sys.stderr.write("需要 PyMuPDF：pip install pymupdf\n")
    raise SystemExit(2)

# 已知期刊的页面尺寸与页眉特征（单位 bp）
PROFILE_RULES = [
    ("IEEE Transactions（Letter，双栏）", 612.0, 792.0, ("IEEE TRANSACTIONS", "IEEE JOURNAL", "IEEE TRANS.")),
    ("JAMA（Letter，宽边距）", 612.0, 792.0, ("JAMA", "JOURNAL OF THE AMERICAN MEDICAL ASSOCIATION")),
    ("Nature", 595.276, 790.866, ("NATURE", "NATURE REVIEWS", "NATURE GENETICS", "NATURE METHODS")),
    ("Science", 594.0, 756.0, ("SCIENCE", "AAAS")),
    ("NEJM", 567.0, 756.0, ("NEW ENGLAND JOURNAL OF MEDICINE", "N ENGL J MED")),
    ("The Lancet", 595.276, 799.37, ("LANCET", "THE LANCET")),
    ("The BMJ", 595.276, 793.701, ("BMJ", "BRITISH MEDICAL JOURNAL")),
    ("European Heart Journal", 595.276, 793.701, ("EUROPEAN HEART JOURNAL", "ESC")),
    ("Circulation", 585.0, 783.0, ("CIRCULATION", "CIRCULATION RESEARCH")),
    ("A4（通用）", 595.276, 841.89, ()),
]

NUMBERED_HEADING = re.compile(r"^(?:[IVX]+\.|[A-Z]\.|\d{1,2}\.)\s+\S")
NAMED_HEADING = re.compile(
    r"^(?:Abstract|Introduction|Related Work|Background|Materials and Methods|Methods?|"
    r"Experiments?|Results?|Discussion|Conclusions?|References|Acknowledg(?:e)?ments?|"
    r"Appendix|Supplementary)\b", re.I)
BOLD = 16  # PyMuPDF span flags: bit 4 = bold


def norm(s: str) -> str:
    return re.sub(r"\s+", " ", s).strip()


def is_bold(line) -> bool:
    return bool(int(line.get("flags", 0)) & BOLD)


def detect_columns(lines, page_width: float) -> int:
    xs = [l["bbox"][0] for l in lines if (l["bbox"][2] - l["bbox"][0]) < 0.72 * page_width]
    if len(xs) < 20:
        return 1
    band = max(8.0, page_width * 0.02)
    buckets = Counter(int(x // band) for x in xs)
    common = [b for b, c in buckets.items() if c >= max(5, len(xs) * 0.08)]
    if not common:
        return 1
    common.sort()
    if len(common) >= 2 and (common[-1] - common[0]) * band > 0.25 * page_width:
        return 2
    return 1


def page_lines(page):
    out = []
    d = page.get_text("dict")
    for b in d.get("blocks", []):
        if b.get("type") != 0:
            continue
        for l in b.get("lines", []):
            spans = [s for s in l.get("spans", []) if s.get("text", "").strip()]
            if not spans:
                continue
            text = "".join(s["text"] for s in spans)
            sizes = [s["size"] for s in spans]
            fonts = [s["font"] for s in spans]
            out.append({
                "bbox": [round(v, 2) for v in l["bbox"]],
                "text": text,
                "size": round(sum(sizes) / len(sizes), 2),
                "font": Counter(fonts).most_common(1)[0][0],
                "flags": int(spans[0].get("flags", 0)),
            })
    return out


def reading_order(lines, page_width: float, header_cut: float, footer_cut: float, columns: int):
    body = [l for l in lines if l["bbox"][1] >= header_cut and l["bbox"][3] <= footer_cut]
    full = [l for l in body if (l["bbox"][2] - l["bbox"][0]) >= 0.72 * page_width]
    rest = [l for l in body if l not in full]
    if columns == 1:
        return sorted(body, key=lambda l: (round(l["bbox"][1], 1), l["bbox"][0]))
    left = sorted([l for l in rest if l["bbox"][0] < page_width / 2], key=lambda l: (round(l["bbox"][1], 1), l["bbox"][0]))
    right = sorted([l for l in rest if l["bbox"][0] >= page_width / 2], key=lambda l: (round(l["bbox"][1], 1), l["bbox"][0]))
    return sorted(full, key=lambda l: l["bbox"][1]) + left + right


def guess_kind(text: str, body_size: float = 10.0, bold: bool = False, size: float = 0.0) -> str:
    t = norm(text)
    if re.match(r"^Fig(?:ure)?\.?\s*\d+", t):
        return "caption"
    if re.match(r"^(TABLE|Table)\s+[IVX\d]+", t):
        return "table"
    if re.match(r"^\[\d+\]", t):
        return "reference"
    if t.lower().startswith("abstract"):
        return "abstract"
    if len(t) < 120 and NUMBERED_HEADING.match(t):
        if re.match(r"^[A-Z]\.\s", t) and len(t) > 45:
            return "body"
        return "heading"
    if len(t) < 80 and NAMED_HEADING.match(t) and (bold or size >= body_size * 1.08) and not t.endswith("."):
        return "heading"
    return "body"


def detect_tables(lines):
    rows = []
    for l in lines:
        toks = norm(l["text"]).split()
        nums = [t for t in toks if re.fullmatch(r"[-+]?\d+(?:\.\d+)?%?", t)]
        if len(nums) >= 3 and len(nums) >= len(toks) * 0.5:
            rows.append({"y": round(l["bbox"][1], 1), "n": len(nums), "text": norm(l["text"])[:120]})
    return rows


def profile_hint(width, height, headers):
    head = " ".join(headers).upper()
    matches = []
    for name, w, h, keys in PROFILE_RULES:
        if abs(width - w) <= 2.0 and abs(height - h) <= 2.0:
            key_hit = any(k in head for k in keys) if keys else False
            matches.append((5 if key_hit else 2, name, (w, h)))
    if not matches:
        return {"profile": "未知（按实际页面尺寸适配）", "confidence": "low",
                "page_size": [round(width, 2), round(height, 2)]}
    matches.sort(key=lambda m: m[0], reverse=True)
    top = matches[0]
    same = [m for m in matches if m[0] == top[0]]
    if top[0] >= 5:
        return {"profile": top[1], "confidence": "high", "page_size": list(top[2])}
    if len(same) == 1:
        return {"profile": top[1], "confidence": "medium", "page_size": list(top[2])}
    # 尺寸同时命中多本期刊且页眉无特征词：不做猜测
    return {"profile": "未知（A4 类双栏/单栏，按实测适配）", "confidence": "low",
            "page_size": [round(width, 2), round(height, 2)]}


def merge_title(lines, body_size, page_height):
    """合并首页大字号标题行：按“字号×字符数”选出标题字号，避免选中首字下沉的单字。"""
    cand = [l for l in lines if l["size"] >= max(body_size * 1.45, 10.0) and len(norm(l["text"])) > 1]
    if not cand:
        return ""
    weight = Counter()
    for l in cand:
        weight[l["size"]] += len(norm(l["text"]))
    top = weight.most_common(1)[0][0]
    group = [l for l in cand if abs(l["size"] - top) <= 0.25 and l["bbox"][1] < 0.45 * page_height]
    group.sort(key=lambda l: (round(l["bbox"][1], 0), l["bbox"][0]))
    return norm(" ".join(x["text"] for x in group[:3]))


def main():
    ap = argparse.ArgumentParser(description="解析论文 PDF，生成翻译工程目录")
    ap.add_argument("pdf")
    ap.add_argument("-o", "--out", required=True)
    ap.add_argument("--dpi", type=int, default=600, help="整页渲染的参考 dpi（图片按原始分辨率保存）")
    ap.add_argument("--no-render", action="store_true", help="跳过整页 PNG 渲染")
    ap.add_argument("--min-px", type=int, default=20, help="小于该像素边长的图片忽略（默认 20）")
    args = ap.parse_args()

    src = os.path.abspath(args.pdf)
    out = os.path.abspath(args.out)
    for sub in ("text", "pages", "assets"):
        os.makedirs(os.path.join(out, sub), exist_ok=True)

    doc = fitz.open(src)
    if doc.page_count == 0:
        raise SystemExit("PDF 没有页面")
    p0 = doc[0]
    width, height = p0.rect.width, p0.rect.height

    pages_detail = []
    all_headings, all_tables, all_headers = [], [], []
    font_counter = Counter()
    images_index = {}

    for pno in range(doc.page_count):
        page = doc[pno]
        lines = page_lines(page)
        for l in lines:
            font_counter[l["font"]] += len(l["text"])

        header_cut = 0.06 * height
        footer_cut = 0.94 * height
        headers = [norm(l["text"]) for l in lines if l["bbox"][3] < header_cut
                   and not re.fullmatch(r"\d+", norm(l["text"]))]
        footers = [norm(l["text"]) for l in lines if l["bbox"][1] > footer_cut]
        all_headers.extend(headers)

        columns = detect_columns(lines, width)
        ordered = reading_order(lines, width, header_cut, footer_cut, columns)

        with open(os.path.join(out, "text", f"page-{pno+1:03d}.txt"), "w", encoding="utf-8") as f:
            for l in ordered:
                f.write(l["text"] + "\n")

        for l in ordered:
            t = norm(l["text"])
            if guess_kind(t, 10.0, is_bold(l), l["size"]) == "heading" and len(t) < 120:
                all_headings.append({"page": pno + 1, "text": t, "size": l["size"],
                                     "bbox": l["bbox"]})

        for row in detect_tables(ordered):
            row["page"] = pno + 1
            all_tables.append(row)

        page_imgs = []
        for im in page.get_images(full=True):
            xref = im[0]
            rects = page.get_image_rects(xref)
            if not rects:
                continue
            # 过滤装饰性小图（图例小图标、下载标记碎片等）
            big = max(rects, key=lambda r: r.width * r.height)
            if big.width * big.height < 400 or big.width < 5 or big.height < 5:
                continue
            key = (pno + 1, xref)
            if key not in images_index:
                pix = fitz.Pixmap(doc, xref)
                if pix.n - pix.alpha >= 4:
                    pix = fitz.Pixmap(fitz.csRGB, pix)
                if pix.width < args.min_px or pix.height < args.min_px:
                    continue
                name = f"img-p{pno+1:03d}-{xref}.png"
                pix.save(os.path.join(out, "assets", name))
                images_index[key] = {
                    "asset": f"assets/{name}",
                    "page": pno + 1,
                    "xref": xref,
                    "px": [pix.width, pix.height],
                    "rects": [],
                }
            if key in images_index:
                for r in rects:
                    images_index[key]["rects"].append([round(v, 2) for v in r])
        for k, v in images_index.items():
            if v["page"] == pno + 1:
                page_imgs.append(v)

        drawings = len(page.get_drawings())
        fig_candidates = []
        if drawings > 120:
            fig_candidates.append({"type": "vector", "drawings": drawings})
        if len(page_imgs) >= 4:
            fig_candidates.append({"type": "raster-grid", "count": len(page_imgs)})

        pages_detail.append({
            "page": pno + 1,
            "columns": columns,
            "lines": ordered,
            "images": page_imgs,
            "drawings": drawings,
            "headers": headers,
            "footers": footers,
            "figure_candidates": fig_candidates,
        })

        if not args.no_render:
            page.get_pixmap(dpi=110).save(os.path.join(out, "pages", f"page-{pno+1:03d}.png"))

    body_size = Counter()
    for pg in pages_detail:
        for l in pg["lines"]:
            body_size[round(l["size"], 1)] += len(l["text"])
    body_size = body_size.most_common(1)[0][0] if body_size else 10.0

    # 用正文主字号重新判定章节
    all_headings = []
    for pg in pages_detail:
        for l in pg["lines"]:
            t = norm(l["text"])
            if guess_kind(t, body_size, is_bold(l), l["size"]) == "heading" and len(t) < 120:
                all_headings.append({"page": pg["page"], "text": t, "size": l["size"], "bbox": l["bbox"]})

    title_candidate = merge_title(pages_detail[0]["lines"], body_size, height)

    ref_start = None
    for pg in pages_detail:
        for l in pg["lines"]:
            if re.match(r"^REFERENCES?$", norm(l["text"]), re.I):
                ref_start = pg["page"]
                break
        if ref_start:
            break
    if ref_start is None:
        for pg in pages_detail:
            if any(re.match(r"^\[\d+\]", norm(l["text"])) for l in pg["lines"]):
                ref_start = pg["page"]
                break

    hint = profile_hint(width, height, all_headers)
    result = {
        "pdf": src,
        "pages": doc.page_count,
        "page_size": [round(width, 2), round(height, 2)],
        "metadata": doc.metadata or {},
        "title_candidate": title_candidate,
        "profile_hint": hint,
        "headers": sorted(set(h for h in all_headers if h))[:10],
        "fonts": font_counter.most_common(10),
        "body_size": body_size,
        "headings": all_headings,
        "tables": all_tables,
        "references_start_page": ref_start,
        "pages_detail": pages_detail,
    }

    with open(os.path.join(out, "source.json"), "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=1)

    with open(os.path.join(out, "coverage.csv"), "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(["page", "order", "kind", "source_text", "status", "note"])
        for pg in pages_detail:
            for i, l in enumerate(pg["lines"]):
                w.writerow([pg["page"], i + 1,
                            guess_kind(l["text"], body_size, is_bold(l), l["size"]),
                            norm(l["text"])[:200], "", ""])

    lines = [
        "# 原文解析清单",
        "",
        f"- 文件：`{src}`",
        f"- 页数：{doc.page_count}",
        f"- 页面尺寸：{width:.2f} × {height:.2f} bp",
        f"- 版式提示：{hint['profile']}（置信度 {hint['confidence']}）",
        f"- 正文主字号：{body_size} bp",
        f"- 主要字体：{', '.join(k for k, _ in font_counter.most_common(5))}",
        f"- 页眉：{' / '.join(sorted(set(h for h in all_headers if h))[:3]) or '（无）'}",
        f"- 参考文献起始页：{ref_start if ref_start else '未识别'}",
        "",
        "## 标题候选",
        "",
        f"> {title_candidate or '（未识别）'}",
        "",
        "## 章节候选",
        "",
    ]
    for h in all_headings[:60]:
        lines.append(f"- p{h['page']} · {h['text']}")
    lines += ["", "## 图片资源", "", "| 页 | 资源 | 像素 | 版面位置 |", "|---|---|---|---|"]
    for v in images_index.values():
        r = v["rects"][0] if v["rects"] else [0, 0, 0, 0]
        lines.append(f"| p{v['page']} | `{v['asset']}` | {v['px'][0]}×{v['px'][1]} | "
                     f"({r[0]:.0f},{r[1]:.0f})-({r[2]:.0f},{r[3]:.0f}) |")
    lines += ["", "## 表格候选（数字密集行）", ""]
    for t in all_tables[:40]:
        lines.append(f"- p{t['page']} · {t['text']}")
    lines += ["", "## 下一步", "",
              "1. 对照 `pages/` 逐页确认内容边界（摘要、正文、方法、图表注、声明、文献、作者简介）。",
              "2. 按 `coverage.csv` 翻译并在 `status` 填 done；正文用 `text/` 的阅读顺序。",
              "3. 图片优先复用 `assets/`；结构示意图可用 TikZ 重绘。",
              ""]
    with open(os.path.join(out, "inventory.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(lines))

    print(f"OK  pages={doc.page_count}  size={width:.0f}x{height:.0f}  "
          f"profile={hint['profile']}  headings={len(all_headings)}  images={len(images_index)}")
    print(f"out: {out}")


if __name__ == "__main__":
    main()
