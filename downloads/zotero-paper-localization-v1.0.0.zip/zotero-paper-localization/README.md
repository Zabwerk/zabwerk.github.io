**简体中文**

# Zotero 论文汉化

一条流水线，把 Zotero 里的英文论文变成按原刊版式排好的中文 PDF 和可编辑源文件。

## 它做什么

```text
Zotero 条目 → 取 PDF → 解析版式与内容 → 全文翻译 → 按原刊排版 → 编译/校验 → PDF + 源包
```

- **取文**：通过 DSH 的 Zotero 工具定位条目、读取最佳 PDF 附件；只读，不写库。
- **解析**：`prepare_source.py` 输出页面尺寸、栏数、字体、逐行文本、图片 bbox、标题/章节候选、覆盖表。
- **版式**：识别 IEEE / Nature / Science / NEJM / Lancet / BMJ / EHJ / Circulation 等页面特征；IEEE 用内置模板，其余复用 `cns-paper-translation` 的 18 套样板。
- **翻译**：全文覆盖，保留数值、公式、图表编号与文献；图注完整；文末附原文信息。
- **校验**：`check_translation.py` 查数值/引文/图表覆盖，`build_pdf.py` 编译并逐页渲染体检。

## 一条指令

> 使用 `$zotero-paper-localization` 把 Zotero 里的这篇论文完整汉化，按原刊版式排版，输出中文 PDF 和可编辑源文件，并在文末附原文信息。

## 目录

```
SKILL.md                 完整流程与规则
scripts/
  prepare_source.py      PDF → 结构化清单、阅读顺序文本、页面渲染、图片素材
  check_translation.py   译稿 vs 原文：数值/引文/图表/图片/章节
  build_pdf.py           编译 + 版面体检 + 逐页渲染
assets/ieee/             IEEE Transactions 中性模板（ieee-article.tex + ieee-style.tex）
references/              Zotero 取文边界、版式映射、验收清单
```

## 依赖

- Python 3.10+，PyMuPDF（`pip install pymupdf`）
- XeLaTeX（TeX Live 2023+）
- 中文字体：SimSun、SimHei、KaiTi

## 注意

- 本技能是“取文 + 汉化排版”的整合层，不替代 `cns-paper-translation` 的期刊模板库。
- 只读 Zotero；写库需用户在 DSH 设置中开启写权限并明确要求。
- 仅供学术交流，原文版权归原作者及出版商所有。
