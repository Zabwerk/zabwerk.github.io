# 版式识别与模板映射

`prepare_source.py` 的 `profile_hint` 只做初判；最终以首页与正文页的实测为准。

## 判定顺序

1. 页面尺寸（容差 ±2 bp）。
2. 页眉字符串（IEEE / Nature / LANCET / BMJ …）。
3. 首行与页脚位置、栏数、正文字号、字体名。
4. 首页结构：通栏题名、摘要位置、日期栏、作者单位、关键词位置。

## 映射表

| 尺寸（bp） | 版式 | 入口 |
|---|---|---|
| 612 × 792，双栏，页眉 IEEE | IEEE Transactions | `assets/ieee/ieee-article.tex` |
| 595.276 × 790.866 | Nature / Nature 子刊 | `nature.tex`、`nature-*.tex` |
| 594 × 756 | Science | `science.tex` |
| 567 × 756 | NEJM | `nejm.tex` |
| 595.276 × 799.37 | The Lancet | `lancet.tex` |
| 595.276 × 793.701 | BMJ / EHJ | `bmj.tex`、`european-heart-journal*.tex` |
| 585 × 783 | Circulation / Circ. Research | `circulation*.tex` |
| 595.276 × 841.89 | A4 通用 | 以 `nature.tex` 为基础改纸型与页边距 |

模板库：`<skills-dir>/cns-paper-translation/assets/templates/`（`<skills-dir>` 指 DSH 的 skills 目录）。

## IEEE 实测参数（已核验）

- 纸型 612 × 792 bp（Letter）。
- 正文左右边界约 49 / 563 bp；两栏起点约 54 / 312 bp；栏宽约 246 bp，栏距约 15.5 bp。
- 正文 10/12 bp（原刊 9.96/12）；中文模板用 10/13 bp 提升可读性；图注 8 bp，表注 8 bp，参考文献 8 bp。
- 题名约 24 bp，作者约 11 bp，一级节标题约 10 bp 小型大写，二级节标题斜体 10 bp。
- 页眉：左刊名 + 右页码；页脚可加“中文译页 / 非官方中文译稿 / 第 X 页 共 Y 页”。
- 引文：方括号数字，正文右上标或行内；文献表按引用顺序编号。

## 常见偏差

- 页面看似 Letter 但实际是 612 × 792 的预印本：仍按 IEEE 双栏处理，但页眉不要伪造刊名。
- 双栏但栏宽不等（侧栏刊）：以正文主栏为准，侧栏单独排版。
- 单栏综述：不要强套双栏；保留单栏并调整行宽。
- 扫描件：先 OCR；版面坐标以图像为准，不能只信文本层。
