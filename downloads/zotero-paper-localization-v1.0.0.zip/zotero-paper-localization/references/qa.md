# 验收与常见问题

## 自动检查

```text
python scripts/build_pdf.py src/main.tex --render-dir work/render --report work/build.json
python scripts/check_translation.py --source work/source.json --text src --report work/check.json
```

- `build_pdf.py`：xelatex 错误、未定义引用/文献、空白页、`??`、禁用词、字体与图片数量；退出码 0 才算通过。
- `check_translation.py`：数值覆盖、文献编号、图表编号、图片文件、章节数量；缺项必须回原文补齐。

自动检查不能代替视觉核对，也不能证明图内文字、水印或译文语义正确。

## 人工核对

1. 逐页看 `work/render/page-*.png`：缺字、越界、重叠、空白栏、意外空页、图注截断。
2. 对照 `work/pages/page-*.png` 与原文：跨页/跨栏续句只出现一次；图表面板字母齐全。
3. 高风险数值抽查：样本量、剂量、阈值、P 值、区间端点、百分比、比较方向。
4. 图表：正文图全部在参考文献之前；图注与图同页或相邻页；表脚注与缩写说明完整。
5. 文末：参考文献 69 条（按原文数量）、作者简介、原文信息、页脚标识。

## 常见问题

| 现象 | 原因 | 处理 |
|---|---|---|
| 中文缺字/方框 | 字体未装或字体名不对 | 安装 SimSun/SimHei/KaiTi，或改 `ieee-style.tex` 的字体名 |
| 编译报 `Font shape ... undefined` | 中文斜体/小型大写缺失 | 已用 KaiTi 作斜体、SimHei 作粗体；仍缺时用 `AutoFakeSlant` |
| 数值检查报缺 | 数字只在图片/文献条目中，或译文改成了中文数字 | 先确认原文位置；译文保持阿拉伯数字 |
| 引文检查报缺 | 译文改用了“文献 12”而非 `[12]` | 统一保留 `[n]` 或在检查脚本中扩展规则 |
| 图注与图分离 | 浮动体过大 | 缩短图注、调整 `[t]`/`[h]`、必要时拆图 |
| 双栏末页不平衡 | 最后一页文字少 | `\balance` 或手动调图 |
| 下载标记残留 | 只裁了 CropBox | 定位承载对象后删除调用与资源；或改用干净素材 |

## 交付前

- 源包文件清单与最终 PDF 一致；ZIP 完整性校验通过；无原始 PDF、无下载标记素材、无机器专属绝对路径。
- `README.md` 写明编译命令、字体依赖、图表处理方式与已知限制。
- 回复中说明范围限制，不把模板演示当成已完成论文。
