---
name: zotero-paper-localization
description: Zotero 论文汉化（一体化）：从 Zotero 文献库定位论文并读取 PDF，完整译成中文，按原刊版式排版，输出中文 PDF 与可编辑源包。内置原文解析、期刊版式识别、IEEE 中性模板、数值/引文/图表覆盖检查与编译体检脚本；适用于“汉化 Zotero 里的这篇论文”“从 Zotero 取文献做成中文 PDF”“按原刊版式翻译这篇文献”。仅摘要解读、文献综述或论文原创写作不需要此技能。
---

# Zotero 论文汉化（一体化）

把“从 Zotero 取论文”和“按原刊版式汉化排版”合并成一条流水线：**定位文献 → 解析原文 → 选定版式 → 全文翻译 → 排版编译 → 校验交付**。本技能只读 Zotero 库与 PDF；不写入、不改动文献条目。

与 `cns-paper-translation` 的分工：本技能负责“Zotero 取文 + 原刊版式 + 全流程脚本”，期刊模板库仍复用后者的 18 套样板；若用户已提供 PDF 或只要求换版式，可直接用后者。

## 何时使用

- 用户给出 Zotero 条目、DOI 或标题，要求“完整汉化成中文 PDF”。
- 用户说“从 Zotero 里把这篇论文译出来，按原刊排版”。
- 用户要求“中文版 + 可编辑源文件”，并希望保留图表、文献与原文信息。

不适用：只要摘要翻译、只要文献检索、只要论文润色或原创写作。

## 流程

### 第 0 步：定位文献（Zotero，只读）

1. 用 `zotero_search`（metadata 模式）按标题/作者/DOI 找条目；必要时用 `zotero_match_references`。
2. 用 `zotero_get` 读取条目，`include` 至少带 `attachments`，`locations` 用 `best`，拿到 PDF 的本地绝对路径。
3. 记录：条目 ref、作者、英文原题、期刊、年份、卷、期、页码/文章号、DOI、附件路径。
4. 规则：
   - 不调用 Zotero 本地 API，不读数据库文件，不绕过工具。
   - 不写库；本会话若写工具关闭，只起草不落库。
   - 没有 PDF 附件时停止，向用户说明缺什么；不要静默改用网页版本。
   - 连接失败时报告具体错误（Zotero 未运行 / 本地 API 未开 / 版本不兼容），等用户修复。

### 第 1 步：解析原文（脚本）

```text
python scripts/prepare_source.py "<PDF 绝对路径>" -o work --dpi 600
```

产出：

| 文件 | 用途 |
|---|---|
| `work/source.json` | 页数、页面尺寸、字体、逐行 bbox、图片 bbox、标题/章节候选、版式提示 |
| `work/text/page-XXX.txt` | 按栏重排的阅读顺序文本 |
| `work/pages/page-XXX.png` | 整页渲染，逐页核对内容边界 |
| `work/assets/img-*.png` | PDF 内原始位图（按原始分辨率提取） |
| `work/inventory.md` | 人读清单：标题、章节、图片、表格、参考文献起始页 |
| `work/coverage.csv` | 逐行覆盖表，翻译时把 `status` 填 `done` |

解析后先做**内容清单**：摘要、正文各节、方法、图表与完整图注、参考文献、致谢/资助/作者贡献/利益冲突/数据与许可声明、作者简介。仅提及但未提供的补充材料不算已取得。

### 第 2 步：选定版式

看 `profile_hint`，再对照 `work/pages/page-001.png` 与正文页确认：

| 页面尺寸（bp） | 版式 | 模板 |
|---|---|---|
| 612 × 792，双栏，页眉含 IEEE | IEEE Transactions | `assets/ieee/ieee-article.tex` |
| 595.276 × 790.866 | Nature 系列 | `cns-paper-translation/assets/templates/nature*.tex` |
| 594 × 756 | Science | `science.tex` |
| 567 × 756 | NEJM | `nejm.tex` |
| 595.276 × 799.37 | The Lancet | `lancet.tex` |
| 595.276 × 793.701 | BMJ / EHJ | `bmj.tex` / `european-heart-journal.tex` |
| 585 × 783 | Circulation | `circulation.tex` |
| 其他 | 按原文实测适配 | 复制最接近的一套再改 |

模板目录：`<skills-dir>/cns-paper-translation/assets/templates/`（`<skills-dir>` 指 DSH 的 skills 目录，Windows 上一般是 `%USERPROFILE%\.dsh\skills`）。复制**整个目录**以保留共享文件；模板里的题名、作者、图、文献都是占位内容，必须替换。

IEEE 版式要点（已核验）：Letter 612×792 bp；左右边距约 45/49 bp；栏宽约 251.5 bp、栏距约 15.5 bp；正文 10/13 bp（中文适配，原刊 9.96/12 bp）；图注 8 bp；页眉刊名与页码；文末英文文献 + 作者简介 + 原文信息。

### 第 3 步：全文翻译

- 以 `work/text/` 的阅读顺序为底本，逐段翻译；跨页/跨栏续句只保留一次。
- 保留：数值、单位、样本量、剂量、统计阈值、公式与编号、图表编号、文献编号、否定与比较方向。
- 术语首次出现给中文 + 英文/缩写，后文统一；基因/蛋白大小写、上下标、阳性/阴性标记原样保留。
- 参考文献保留英文原文与编号，正文引用指向对应条目；中文评注单独放。
- 图注完整翻译；图内英文保留时，在图注或文末给出逐项中文对照；要求替换图内文字时再做可核对的重绘。
- 新建或完整重排的译稿，文末必须有独立“原文信息”：作者、英文原题、期刊、年份、卷期、页码/文章号、DOI；缺项不编造。
- 排除个人下载来源、机构/IP、下载日期等旁栏标记；保留作者单位、科学坐标轴、版权许可与正常刊头页脚。

### 第 4 步：排版与编译

1. 复制模板到任务目录（如 `src/`），保留 `figs/` 相对位置。
2. 填入译文；图表按“首次实质讨论附近”插入，正文图全部排在参考文献之前。
3. 编译：

```text
python scripts/build_pdf.py src/main.tex --render-dir work/render --report work/build.json
```

脚本会跑两遍 XeLaTeX，检查错误、未定义引用/文献、空白页、`??`、禁用词，并逐页渲染 PNG。

### 第 5 步：校验与交付

```text
python scripts/check_translation.py --source work/source.json --text src --report work/check.json
```

检查数值覆盖、文献编号、图表编号、图片文件是否存在、章节数量。**任何缺项都要回到对应段落补齐**，不能靠“检查通过”代替人工核对。

交付：

- 最终 PDF（文件名含中文题名与期刊年份）。
- 可编辑源包：`src/`、`figs/`、编译脚本、`README.md`、`MANIFEST.txt`（SHA-256）。
- 源包不含原始 PDF、下载标记素材、临时抽取文件与机器专属路径。
- 回复中说明：译稿范围、版式、图表处理方式（复用/重绘）、图内英文保留情况、已知限制。

## 脚本

| 脚本 | 作用 |
|---|---|
| `scripts/prepare_source.py` | PDF → 结构化清单、阅读顺序文本、页面渲染、图片素材、覆盖表 |
| `scripts/check_translation.py` | 译稿 vs 原文：数值/引文/图表/图片/章节覆盖 |
| `scripts/build_pdf.py` | 编译 + 版面体检 + 逐页渲染 |

依赖：Python 3.10+、PyMuPDF、XeLaTeX（TeX Live 2023+）、SimSun/SimHei/KaiTi 字体。

## 常见问题

- **Zotero 没有 PDF**：停止并说明；请用户先在 Zotero 中补附件，或提供本地 PDF。
- **扫描版 PDF**：`prepare_source.py` 提取不到文字时，先 OCR，再对照页面图像校核；不要把 OCR 噪声当原文。
- **双栏串行**：`text/` 已按栏重排；跨栏续句若仍错位，用 `pages/` 图像核对。
- **图片是矢量结构图**：优先保留原图并译图注；需要图内中文时用 TikZ 重绘，保持数据与连线不变。
- **编译缺字**：确认 `SimSun/SimHei/KaiTi` 已安装，或改用本机可用的中文字体并在 `ieee-style.tex` 中替换。
- **数值检查误报**：图内数字、参考文献页码、公式编号可能只在图片/文献条目中；确认后可在报告中注明，不要篡改原文数值。

## 验收清单

- [ ] 内容清单逐项有对应译文，无漏段、重段、截断图注。
- [ ] 数值、公式、图表编号、文献编号可追溯。
- [ ] 每页渲染可读：无缺字、越界、重叠、空白栏、意外空页。
- [ ] 图表在参考文献之前，图注与图同页或相邻页。
- [ ] 页脚区分原刊信息与“中文译页”，并有非官方译稿声明。
- [ ] 文末“原文信息”完整。
- [ ] `build_pdf.py` 与 `check_translation.py` 均 PASS；差异已人工确认。

仅供学术交流，原文版权归原作者及出版商所有。
